<?php
/**
 * Copyright © 2017 Mageside. All rights reserved.
 * See MS-LICENSE.txt for license details.
 */
namespace Mageside\CanadaPostShipping\Model\Source;

class ShipmentOptions implements \Magento\Framework\Option\ArrayInterface
{
    /**
     * {@inheritdoc}
     */
    public function toOptionArray()
    {
        return [
            ['value' => 'COD', 'label' => __('COD')],
            ['value' => 'PA18', 'label' => __('Proof of Age Required - 18')],
            ['value' => 'PA19', 'label' => __('Proof of Age Required - 19')],
            ['value' => 'HFP', 'label' => __('Card for pickup')],
            ['value' => 'DNS', 'label' => __('Do not safe drop')],
            ['value' => 'LAD', 'label' => __('Leave at door - do not card')]
        ];
    }
}
