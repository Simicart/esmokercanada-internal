<?php
/**
 * Copyright © 2017 Mageside. All rights reserved.
 * See MS-LICENSE.txt for license details.
 */
namespace Mageside\CanadaPostShipping\Model\Service;

/**
 * Class Shipment
 * @package Mageside\CanadaPostShipping\Model\Service
 * @documentation https://www.canadapost.ca/cpo/mc/business/productsservices/developers/services/shippingmanifest/soap/createshipment.jsf
 * @documentation https://www.canadapost.ca/cpo/mc/business/productsservices/developers/services/onestepshipping/soap/createshipment.jsf
 */
class Shipment extends \Mageside\CanadaPostShipping\Model\Service\AbstractService
{
    /**
     * @param $request
     * @return array
     */
    public function getShipmentData($request)
    {
        $client = $this->createSoapClient('shipment');
        $requestClient = $this->formShipmentRequest($request);
        $operation = $this->_carrierHelper->isContractShipment() ? 'CreateShipment' : 'CreateNCShipment';
        $response = $client->__soapCall($operation, $requestClient, null, null);

        $result = [];
        $result['client'] = $client;
        if (isset($response->{'messages'})) {
            $debugData = [
                'request'   => $client->__getLastRequest(),
                'response'  => $client->__getLastResponse(),
                'result'    => ['error' => '', 'code' => '', 'xml' => $client->__getLastResponse()],
            ];
            if (is_array($response->{'messages'}->{'message'})) {
                foreach ($response->{'messages'}->{'message'} as $message) {
                    $debugData['result']['code'] .= $message->code . '; ';
                    $debugData['result']['error'] .= $message->description . '; ';
                }
            }
            $result['error'] = true;
            $result['debug'] = $debugData;
        } else {
            $responseData = null;
            if (isset($response->{'non-contract-shipment-info'})) {
                $responseData = $response->{'non-contract-shipment-info'};
            } elseif (isset($response->{'shipment-info'})) {
                $responseData = $response->{'shipment-info'};
            }
            if ($responseData) {
                $artifacts = [];
                foreach ($responseData->{'artifacts'}->{'artifact'} as $artifact) {
                    $artifacts[] = [
                        'artifact_id' => $artifact->{'artifact-id'},
                        'page_index' => $artifact->{'page-index'}
                    ];
                }

                if ($cpShipment = $this->_registry->registry('canadapost_shipment')) {
                    $cpShipment->setShipmentId($responseData->{'shipment-id'});
                    if (isset($responseData->{'shipment-status'})) {
                        $cpShipment->setStatus($responseData->{'shipment-status'});
                    }
                }

                $result['label_content'] = $this->_artifactService->create()->getArtifacts($artifacts);
                if ($responseData->{'tracking-pin'}) {
                    $result['tracking_number'] = $responseData->{'tracking-pin'};
                    if ($cpShipment) {
                        $cpShipment->setTrackingNumber($responseData->{'tracking-pin'});
                    }
                }
            }

            $result['debug'] = [
                'request'   => $client->__getLastRequest(),
                'response'  => $client->__getLastResponse()
            ];
        }

        return $result;
    }

    /**
     * Form array with appropriate structure for shipment request
     *
     * @param \Magento\Framework\DataObject $request
     * @return array
     * @SuppressWarnings(PHPMD.CyclomaticComplexity)
     * @SuppressWarnings(PHPMD.NPathComplexity)
     * @SuppressWarnings(PHPMD.ExcessiveMethodLength)
     */
    public function formShipmentRequest(\Magento\Framework\DataObject $request)
    {
        if ($request->getReferenceData()) {
            $referenceData = $request->getReferenceData() . $request->getPackageId();
        } else {
            $referenceData = 'Order #' .
                $request->getOrderShipment()->getOrder()->getIncrementId() .
                ' P' .
                $request->getPackageId();
        }

        $packageParams = $request->getPackageParams();
        $weight = $this->convertWeightToKg($request->getPackageWeight(), $packageParams->getWeightUnits());
        $height = $this->convertDimensionToCm($packageParams->getHeight(), $packageParams->getDimensionUnits());
        $width = $this->convertDimensionToCm($packageParams->getWidth(), $packageParams->getDimensionUnits());
        $length = $this->convertDimensionToCm($packageParams->getLength(), $packageParams->getDimensionUnits());

        $deliveryRequest = [
            'service-code' => $request->getShippingMethod(),
            'sender' => [
                'company' => $request->getShipperContactCompanyName(),
                'contact-phone' => $request->getShipperContactPhoneNumber(),
                'address-details' => [
                    'address-line-1' => $request->getShipperAddressStreet(),
                    'address-line-2' => $request->getShipperAddressStreet2() ?
                        $request->getShipperAddressStreet2() :
                        '',
                    'city' => $request->getShipperAddressCity(),
                    'prov-state' => $request->getShipperAddressStateOrProvinceCode(),
                    'postal-zip-code' => $this->formatPostCode($request->getShipperAddressPostalCode())
                ]
            ],
            'destination' => [
                'name' => $request->getRecipientContactPersonName(),
                'company' => $request->getRecipientContactCompanyName() ?
                    $request->getRecipientContactCompanyName() :
                    '',
                'client-voice-number' => $request->getRecipientContactPhoneNumber(),
                'address-details' => [
                    'address-line-1' => $request->getRecipientAddressStreet(),
                    'address-line-2' => $request->getRecipientAddressStreet2() ?
                        $request->getRecipientAddressStreet2() :
                        '',
                    'city' => $request->getRecipientAddressCity(),
                    'prov-state' => $request->getRecipientAddressStateOrProvinceCode(),
                    'country-code' => $request->getRecipientAddressCountryCode(),
                    'postal-zip-code' => $this->formatPostCode($request->getRecipientAddressPostalCode())
                ]
            ],
            'parcel-characteristics' => [
                'weight' => $weight,
                'unpackaged' => false,
                'mailing-tube'=> false
            ],
            'notification' => [
                'email' => $request->getRecipientEmail(),
                'on-shipment' => $this->_carrierHelper->getNotificationConfig('on-shipment'),
                'on-exception' => $this->_carrierHelper->getNotificationConfig('on-exception'),
                'on-delivery' => $this->_carrierHelper->getNotificationConfig('on-delivery'),
            ],
            'preferences' => [
                'show-packing-instructions' => true,
                'show-postage-rate'         => false,
                'show-insured-value'        => true,
            ],
            'references' => [
                'customer-ref-1' => $referenceData
            ]
        ];

        // set dimensions
        if ($length || $width || $height) {
            $deliveryRequest['parcel-characteristics']['dimensions'] = [
                'length'    => $length,
                'width'     => $width,
                'height'    => $height
            ];
        }

        // set options
        $amount = $request->getPackageParams()->getCustomsValue();
        $options = $this->getOptions(
            $amount,
            $request->getShippingMethod(),
            $request->getRecipientAddressCountryCode()
        );
        if (!empty($options)) {
            $deliveryRequest['options']['option'] = $options;
        }

        // for international shipping
        if ($request->getShipperAddressCountryCode() != $request->getRecipientAddressCountryCode()) {
            /** @var \Mageside\CanadaPostShipping\Model\Currency\Currency $currencyService */
            $currencyService = $this->_currencyFactory->create();
            $reasonForExport = $this->_carrierHelper->getConfigCarrier('reason_for_export');
            $destinationCurrency = $currencyService->getCurrencyCodeByCountry(
                $request->getRecipientAddressCountryCode()
            );
            $currencyRate = $currencyService->getCurrencyRate(
                $request->getBaseCurrencyCode(),
                $destinationCurrency
            );
            if (!$currencyRate) {
                $destinationCurrency = $request->getBaseCurrencyCode();
                $currencyRate = 1;
            }
            $deliveryRequest['customs'] = [
                'currency' => $destinationCurrency,
                'conversion-from-cad' => $currencyRate,
                'reason-for-export' => $reasonForExport,
                'sku-list' => [
                    'item' => $this->getSkuList($request)
                ]
            ];
            if ($reasonForExport == 'OTH') {
                $deliveryRequest['customs']['other-reason'] = substr(
                    $this->_carrierHelper->getConfigCarrier('other_reason_for_export'),
                    0,
                    44
                );
            }

            // Non-delivery handling codes
            $deliveryRequest['options']['option'][]['option-code'] = $this->_carrierHelper
                ->getConfigCarrier('non_delivery_handling');
        }

        if ($this->_carrierHelper->getConfigCarrier('contract_id')) {
            $deliveryRequest['sender']['address-details']['country-code'] = 'CA';
            $deliveryRequest['print-preferences'] = [
                'output-format' => $this->_carrierHelper->getConfigCarrier('output_format'),
                'encoding' => 'PDF'
            ];
            $deliveryRequest['settlement-info'] = [
                'contract-id' => $this->_carrierHelper->getConfigCarrier('contract_id'),
                'intended-method-of-payment' => 'Account'
            ];
            $data = [
                'create-shipment-request' => [
                    'locale' => $this->_carrierHelper->getConfigCarrier('locale'),
                    'mailed-by' => $this->_carrierHelper->getConfigCarrier('customer_number'),
                    'shipment' => [
                        'requested-shipping-point' => $this->formatPostCode($request->getShipperAddressPostalCode()),
                        'expected-mailing-date' => date('Y-m-d'),
                        'delivery-spec' => $deliveryRequest
                    ]
                ]
            ];
            if ($manifest = $this->_registry->registry('canadapost_manifest')) {
                $data['create-shipment-request']['shipment']['groupIdOrTransmitShipment']['ns1:group-id'] =
                    $manifest->getGroupId();
            }

            return $data;
        } else {
            return [
                'create-non-contract-shipment-request' => [
                    'locale' => $this->_carrierHelper->getConfigCarrier('locale'),
                    'mailed-by' => $this->_carrierHelper->getConfigCarrier('customer_number'),
                    'non-contract-shipment' => [
                        'requested-shipping-point' => $this->formatPostCode($request->getShipperAddressPostalCode()),
                        'delivery-spec' => $deliveryRequest
                    ]
                ]
            ];
        }
    }

    protected function getOptions($packageAmount, $rateCode, $countryCode)
    {
        /** @var \Mageside\CanadaPostShipping\Model\Service\Rating $rateClient */
        $rateClient = $this->_rateClientFactory->create();
        $coverageAmount = 0;
        if ($rateClient->isCoverageEnabled($packageAmount)) {
            $coverageMaxAmount = $rateClient->getCoverageMaxAmount($rateCode, $countryCode);
            $coverageAmount = min($packageAmount, $coverageMaxAmount);
        }

        return $this->getServiceOptions($packageAmount, $coverageAmount);
    }

    /**
     * Get products data
     *
     * @param $request
     * @return array
     */
    protected function getSkuList($request)
    {
        $skuList = [];
        $productIds = [];
        $packageItems = $request->getPackageItems();
        foreach ($packageItems as $itemShipment) {
            $productIds[] = $itemShipment['product_id'];
        }

        // get countries of manufacture
        $productCollection = $this->_productCollectionFactory->create()->addStoreFilter(
            $request->getStoreId()
        )->addFieldToFilter(
            'entity_id',
            ['in' => $productIds]
        )->addAttributeToSelect(
            'country_of_manufacture'
        );
        $products = $productCollection->getItems();

        foreach ($packageItems as $itemShipment) {
            $item = new \Magento\Framework\DataObject();
            $item->setData($itemShipment);
            $product = $products[$item->getProductId()];

            $data = [
                'customs-number-of-units'   => $item->getQty(),
                'customs-description'       => substr(
                    $item->getName(),
                    0,
                    45
                ),
                'unit-weight'               => $this->convertWeightToKg(
                    $item->getWeight(),
                    $this->getStoreWeightUnit($request->getStoreId())
                ),
                'customs-value-per-unit'    => $this->convertPrice($item->getPrice()),
                'sku'                       => substr(
                    $product->getSku(),
                    0,
                    15
                ),
            ];

            if ($product->getCountryOfManufacture()) {
                $data['country-of-origin'] = $product->getCountryOfManufacture();
            }

            $skuList[] = $data;
        }

        return $skuList;
    }
}
