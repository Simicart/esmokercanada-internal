var config = {
    paths: {
        async: 'Mageside_CanadaPostShipping/js/requirejs-plugins/async'
    }
};