<?php
/**
 * Copyright © 2018 Mageside. All rights reserved.
 * See MS-LICENSE.txt for license details.
 */
namespace Mageside\CanadaPostShipping\Model\Service;

/**
 * Class Manifest
 * @package Mageside\CanadaPostShipping\Model\Service
 * @documentation https://www.canadapost.ca/cpo/mc/business/productsservices/developers/services/shippingmanifest/soap/manifest.jsf
 */
class Manifest extends \Mageside\CanadaPostShipping\Model\Service\AbstractService
{
    /**
     * @param $manifest
     * @return array
     */
    public function getManifestPrint($manifest)
    {
        $messages = '';
        $artifacts = [];
        $response = [];
        if ($manifests = $manifest->getCpManifestId()) {
            foreach (explode(',', $manifests) as $manifestId) {
                $client = $this->createSoapClient('manifest');
                $result = $client->__soapCall(
                    'GetManifestArtifactId',
                    [
                        'get-manifest-artifact-id-request' => [
                            'locale'        => $this->_carrierHelper->getConfigCarrier('locale'),
                            'mailed-by'     => $this->_carrierHelper->getConfigCarrier('customer_number'),
                            'manifest-id'   => $manifestId
                        ]
                    ],
                    null,
                    null
                );

                // Parse Response
                if (isset($result->{'manifest'})) {
                    $artifacts[] = [
                        'artifact_id' => $result->{'manifest'}->{'artifact-id'},
                        'page_index' => 0
                    ];
                } else {
                    foreach ($result->{'messages'}->{'message'} as $message) {
                        $messages .= $message->description . '; ';
                    }
                }
            }
        }

        if (!empty($artifacts)) {
            $response['manifest'] = $this->_artifactService->create()->getArtifacts($artifacts);
        }

        if ($messages) {
            $response['messages'] = $messages;
        }

        return $response;
    }
}
