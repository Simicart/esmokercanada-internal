<?php
/**
 *  Copyright © 2016 Magestore. All rights reserved.
 *  See COPYING.txt for license details.
 *
 */

namespace Magestore\Webpos\Block\Inventory\StockItem;

/**
 * Class Lists
 * @package Magestore\Webpos\Block\Customer
 */
class Lists extends \Magestore\Webpos\Block\AbstractBlock
{

}
