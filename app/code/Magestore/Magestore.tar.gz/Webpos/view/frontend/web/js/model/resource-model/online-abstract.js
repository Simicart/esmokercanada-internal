/*
 *  Copyright © 2016 Magestore. All rights reserved.
 *  See COPYING.txt for license details.
 *
 */

define(
    [
        'jquery',
        'Magestore_Webpos/js/model/resource-model/abstract'
    ],
    function ($, resourceAbstract) {
        "use strict";

        return resourceAbstract.extend({


        });
    }
);